export class GlobalConstants{
    public static genericError:string="something went wrong.Please try again later";
    public static nameRegex:string="[a-zA-Z0-9]*";
    public static contactnumbRegex:string="^[e0-9]{10,10}$";
    public static error:string="error";
}