export class Fooditems {
    foodId?: any;
    foodName?: string;
    itemCost?: number;
}
