export class Venue {
    venueId?: any;
    venueName?: string;
    venueCost?: number;
    location?: string;
    venueContact?: string;
}
