import { Fooditems } from './fooditems.model';

describe('Fooditems', () => {
  it('should create an instance', () => {
    expect(new Fooditems()).toBeTruthy();
  });
});
