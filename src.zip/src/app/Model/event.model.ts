export class Event {

    eventId?: number;
    name?: string;
    eventDesc?: string;

}
