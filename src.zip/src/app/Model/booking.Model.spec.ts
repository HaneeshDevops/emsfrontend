import { Booking } from './booking.Model';

describe('Booking', () => {
  it('should create an instance', () => {
    expect(new Booking()).toBeTruthy();
  });
});
